package com.darwesh.constructionmeasure

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MeasurementRecord(
    val type: String,              // "Distance", "Area", "Material: Tiles", etc.
    val primaryValue: Double,
    val unit: String,
    val secondaryValue: Double? = null,
    val secondaryUnit: String? = null,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun dateString(): String =
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(timestamp))

    fun summary(): String {
        val base = "%s: %.2f %s".format(type, primaryValue, unit)
        return if (secondaryValue != null) {
            base + "  |  %.2f %s".format(secondaryValue, secondaryUnit ?: "")
        } else base
    }
}

/**
 * Simple in-memory store shared across activities for this session.
 * Swap this for a Room database if persistence across app restarts is needed.
 */
object MeasurementStore {
    private val records = mutableListOf<MeasurementRecord>()

    fun add(record: MeasurementRecord) {
        records.add(0, record) // newest first
    }

    fun all(): List<MeasurementRecord> = records.toList()

    fun clear() = records.clear()
}
