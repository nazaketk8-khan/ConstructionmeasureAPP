package com.darwesh.constructionmeasure

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import com.darwesh.constructionmeasure.databinding.ActivityCalculatorBinding
import kotlin.math.ceil

/**
 * Material + cost calculator. Takes an area (sq. meters) — either typed in
 * manually or pulled from the last saved AR measurement — and a material /
 * finish type, and estimates:
 *   1) the physical quantity needed (tiles, litres, bags, bricks, m² of
 *      marble/granite/wood, etc.)
 *   2) an optional total cost, if the user enters a price per unit.
 *
 * Formulas are approximate industry rules of thumb; adjust the constants
 * in calculate() to match local supplier specs.
 */
class CalculatorActivity : BaseActivity() {

    private lateinit var binding: ActivityCalculatorBinding

    private data class MaterialOption(val labelRes: Int, val unitLabel: String)

    private val materials = listOf(
        MaterialOption(R.string.mat_floor_tiles, "piece"),
        MaterialOption(R.string.mat_marble, "m²"),
        MaterialOption(R.string.mat_granite, "m²"),
        MaterialOption(R.string.mat_wood, "m²"),
        MaterialOption(R.string.mat_paint, "litre"),
        MaterialOption(R.string.mat_cement, "bag"),
        MaterialOption(R.string.mat_bricks, "piece")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCalculatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val labels = materials.map { getString(it.labelRes) }
        binding.spinnerMaterial.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, labels
        )

        MeasurementStore.all().firstOrNull { it.type == "Area" }?.let {
            binding.etArea.setText(it.primaryValue.toString())
        }

        binding.btnCalculate.setOnClickListener { calculate() }
        binding.btnSaveResult.setOnClickListener { saveResult() }
    }

    private var lastResultLabel: String = ""
    private var lastResultQuantity: Double = 0.0
    private var lastResultUnit: String = ""
    private var lastTotalCost: Double? = null

    private fun calculate() {
        val areaSqM = binding.etArea.text.toString().toDoubleOrNull()
        if (areaSqM == null || areaSqM <= 0) {
            Toast.makeText(this, getString(R.string.enter_valid_area), Toast.LENGTH_SHORT).show()
            return
        }
        val areaWithWastage = areaSqM * 1.10
        val selected = materials[binding.spinnerMaterial.selectedItemPosition]
        val materialName = getString(selected.labelRes)

        val (label, quantity, unit) = when (materialName) {
            getString(R.string.mat_floor_tiles) ->
                Triple(materialName, ceil(areaWithWastage / 0.36), "pieces")
            getString(R.string.mat_marble) -> Triple(materialName, areaWithWastage, "m²")
            getString(R.string.mat_granite) -> Triple(materialName, areaWithWastage, "m²")
            getString(R.string.mat_wood) -> Triple(materialName, areaWithWastage, "m²")
            getString(R.string.mat_paint) ->
                Triple(materialName, (areaWithWastage / 10.0) * 2, "litres")
            getString(R.string.mat_cement) ->
                Triple(materialName, ceil(areaWithWastage * 0.25), "bags")
            getString(R.string.mat_bricks) ->
                Triple(materialName, ceil(areaWithWastage * 55), "pieces")
            else -> Triple(materialName, 0.0, "")
        }

        lastResultLabel = label
        lastResultQuantity = quantity
        lastResultUnit = unit

        val pricePerUnit = binding.etPrice.text.toString().toDoubleOrNull()
        lastTotalCost = pricePerUnit?.let { it * quantity }

        val quantityLine = "$label: %.2f %s\n${getString(R.string.wastage_note)}"
            .format(quantity, unit)

        val costLine = lastTotalCost?.let {
            "\n\n${getString(R.string.total_cost_label)}: %.2f".format(it)
        } ?: ""

        binding.tvResult.text = quantityLine + costLine
    }

    private fun saveResult() {
        if (lastResultUnit.isEmpty()) {
            Toast.makeText(this, getString(R.string.calculate_first_hint), Toast.LENGTH_SHORT).show()
            return
        }
        MeasurementStore.add(
            MeasurementRecord(
                type = "Material: $lastResultLabel",
                primaryValue = lastResultQuantity,
                unit = lastResultUnit,
                secondaryValue = lastTotalCost,
                secondaryUnit = if (lastTotalCost != null) "total cost" else null
            )
        )
        Toast.makeText(this, getString(R.string.saved_to_history), Toast.LENGTH_SHORT).show()
    }
}
