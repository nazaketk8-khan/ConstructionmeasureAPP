package com.darwesh.constructionmeasure

import android.os.Bundle
import android.widget.Toast
import com.darwesh.constructionmeasure.databinding.ActivityMeasurementBinding
import com.google.ar.core.Anchor
import com.google.ar.core.HitResult
import com.google.ar.core.Plane
import io.github.sceneview.ar.ARSceneView
import io.github.sceneview.ar.node.AnchorNode
import kotlin.math.sqrt

/**
 * AR-based measurement screen.
 *
 * Mode "DISTANCE": user taps two points on a detected plane -> shows distance.
 * Mode "AREA": user taps 3+ points to outline a shape -> shows area (shoelace formula)
 *              and perimeter.
 *
 * Falls back to a manual "reference object" calculator (see CalculatorActivity)
 * on devices/screens where ARCore is unavailable.
 */
class MeasurementActivity : BaseActivity() {

    private lateinit var binding: ActivityMeasurementBinding
    private lateinit var sceneView: ARSceneView

    // World-space points (meters) tapped by the user, in order.
    private val points = mutableListOf<FloatArray>() // each = [x, y, z]
    private val placedAnchors = mutableListOf<AnchorNode>()

    private var mode = Mode.DISTANCE

    enum class Mode { DISTANCE, AREA }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMeasurementBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sceneView = binding.sceneView

        binding.toggleMode.setOnClickListener {
            mode = if (mode == Mode.DISTANCE) Mode.AREA else Mode.DISTANCE
            resetPoints()
            binding.toggleMode.text = if (mode == Mode.DISTANCE)
                getString(R.string.mode_distance) else getString(R.string.mode_area)
        }

        binding.btnReset.setOnClickListener { resetPoints() }

        binding.btnSave.setOnClickListener { saveCurrentMeasurement() }

        // Handle taps on the AR scene to place measurement points.
        sceneView.onTapAr = { hitResult: HitResult, _ ->
            onArTap(hitResult)
        }
    }

    private fun onArTap(hitResult: HitResult) {
        val trackable = hitResult.trackable
        if (trackable is Plane && trackable.isPoseInPolygon(hitResult.hitPose)) {
            val anchor: Anchor = hitResult.createAnchor()
            val anchorNode = AnchorNode(sceneView.engine, anchor)
            sceneView.addChildNode(anchorNode)
            placedAnchors.add(anchorNode)

            val pose = hitResult.hitPose
            points.add(floatArrayOf(pose.tx(), pose.ty(), pose.tz()))

            updateReadout()

            if (mode == Mode.DISTANCE && points.size == 2) {
                // Distance mode locks at 2 points; user taps Reset to measure again.
            }
        } else {
            Toast.makeText(this, getString(R.string.tap_surface), Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateReadout() {
        when (mode) {
            Mode.DISTANCE -> {
                if (points.size >= 2) {
                    val d = distance(points[0], points[1])
                    binding.tvResult.text = formatLength(d)
                }
            }
            Mode.AREA -> {
                if (points.size >= 3) {
                    val area = polygonArea(points)
                    val perimeter = polygonPerimeter(points)
                    binding.tvResult.text = "Area: ${"%.2f".format(area)} m²\n" +
                        "Perimeter: ${formatLength(perimeter)}"
                } else if (points.size in 1..2) {
                    binding.tvResult.text = getString(R.string.tap_more_points, 3 - points.size)
                }
            }
        }
    }

    private fun resetPoints() {
        points.clear()
        placedAnchors.forEach { it.anchor?.detach() }
        placedAnchors.clear()
        binding.tvResult.text = "—"
    }

    private fun saveCurrentMeasurement() {
        if (points.size < 2) {
            Toast.makeText(this, getString(R.string.save_first_hint), Toast.LENGTH_SHORT).show()
            return
        }
        val record = when (mode) {
            Mode.DISTANCE -> MeasurementRecord(
                type = "Distance",
                primaryValue = distance(points[0], points[1]),
                unit = "m"
            )
            Mode.AREA -> MeasurementRecord(
                type = "Area",
                primaryValue = polygonArea(points),
                unit = "m²",
                secondaryValue = polygonPerimeter(points),
                secondaryUnit = "m (perimeter)"
            )
        }
        MeasurementStore.add(record)
        Toast.makeText(this, getString(R.string.saved_to_history), Toast.LENGTH_SHORT).show()
    }

    // ---- Geometry helpers ----

    private fun distance(a: FloatArray, b: FloatArray): Double {
        val dx = (a[0] - b[0]).toDouble()
        val dy = (a[1] - b[1]).toDouble()
        val dz = (a[2] - b[2]).toDouble()
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    /** Shoelace formula projected onto the dominant plane (assumes near-planar points). */
    private fun polygonArea(pts: List<FloatArray>): Double {
        var area = 0.0
        for (i in pts.indices) {
            val j = (i + 1) % pts.size
            area += pts[i][0] * pts[j][2] - pts[j][0] * pts[i][2]
        }
        return kotlin.math.abs(area) / 2.0
    }

    private fun polygonPerimeter(pts: List<FloatArray>): Double {
        var perimeter = 0.0
        for (i in pts.indices) {
            val j = (i + 1) % pts.size
            perimeter += distance(pts[i], pts[j])
        }
        return perimeter
    }

    private fun formatLength(meters: Double): String {
        val feet = meters * 3.28084
        return "%.2f m (%.2f ft)".format(meters, feet)
    }
}
