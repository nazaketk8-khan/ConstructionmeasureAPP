package com.darwesh.constructionmeasure

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import java.util.Locale

/**
 * Handles switching the app's language between English ("en") and Urdu ("ur")
 * at runtime, and remembers the choice across app restarts.
 *
 * Usage:
 *  - Call LocaleHelper.wrap(context) from attachBaseContext() in every Activity
 *    (see BaseActivity) so the saved language is applied on launch.
 *  - Call LocaleHelper.setLanguage(context, "ur") then recreate the activity
 *    to switch languages immediately.
 */
object LocaleHelper {

    private const val PREFS = "locale_prefs"
    private const val KEY_LANG = "selected_language"

    fun getLanguage(context: Context): String {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LANG, "en") ?: "en"
    }

    fun setLanguage(context: Context, language: String) {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LANG, language).apply()
    }

    fun toggleLanguage(context: Context): String {
        val next = if (getLanguage(context) == "en") "ur" else "en"
        setLanguage(context, next)
        return next
    }

    /** Wrap a Context so its resources use the saved language. Call from attachBaseContext(). */
    fun wrap(context: Context): Context {
        val language = getLanguage(context)
        val locale = Locale(language)
        Locale.setDefault(locale)

        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)

        return context.createConfigurationContext(config)
    }
}
