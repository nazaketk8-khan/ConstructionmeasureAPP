package com.darwesh.constructionmeasure

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.content.FileProvider
import com.darwesh.constructionmeasure.databinding.ActivityHistoryBinding
import java.io.File
import java.io.FileOutputStream

/**
 * Shows every saved measurement / calculation from this session and lets the
 * user export the whole list as a one-page-per-N-rows PDF report, which can
 * then be shared directly via WhatsApp/Email using the system share sheet.
 */
class HistoryActivity : BaseActivity() {

    private lateinit var binding: ActivityHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        refreshList()

        binding.btnExportPdf.setOnClickListener { exportToPdf() }
        binding.btnClear.setOnClickListener {
            MeasurementStore.clear()
            refreshList()
        }
    }

    private fun refreshList() {
        val records = MeasurementStore.all()
        val lines = if (records.isEmpty()) {
            listOf(getString(R.string.no_records))
        } else {
            records.map { "${it.dateString()}\n${it.summary()}" }
        }
        binding.listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, lines)
    }

    private fun exportToPdf() {
        val records = MeasurementStore.all()
        if (records.isEmpty()) {
            Toast.makeText(this, getString(R.string.nothing_to_export), Toast.LENGTH_SHORT).show()
            return
        }

        val pdf = PdfDocument()
        val pageWidth = 595 // A4 @ ~72dpi
        val pageHeight = 842
        val margin = 40
        val titlePaint = Paint().apply { textSize = 18f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { textSize = 12f }
        val linesPerPage = 30

        var recordIndex = 0
        var pageNumber = 1

        while (recordIndex < records.size) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            val page = pdf.startPage(pageInfo)
            val canvas = page.canvas

            var y = margin.toFloat()
            canvas.drawText("Construction Measurement Report", margin.toFloat(), y, titlePaint)
            y += 30

            var linesOnPage = 0
            while (recordIndex < records.size && linesOnPage < linesPerPage) {
                val r = records[recordIndex]
                canvas.drawText(r.dateString(), margin.toFloat(), y, bodyPaint)
                y += 16
                canvas.drawText(r.summary(), margin.toFloat(), y, bodyPaint)
                y += 24
                recordIndex++
                linesOnPage++
            }

            pdf.finishPage(page)
            pageNumber++
        }

        val file = File(cacheDir, "measurement_report_${System.currentTimeMillis()}.pdf")
        try {
            FileOutputStream(file).use { pdf.writeTo(it) }
        } finally {
            pdf.close()
        }

        shareFile(file)
    }

    private fun shareFile(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Share measurement report"))
    }
}
