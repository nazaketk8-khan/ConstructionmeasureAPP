package com.darwesh.constructionmeasure

import android.content.Context
import androidx.appcompat.app.AppCompatActivity

/**
 * All activities extend this instead of AppCompatActivity directly, so the
 * user's saved language choice (English/Urdu) is applied automatically every
 * time an activity starts — no need to repeat the logic everywhere.
 */
abstract class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }
}
