plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.darwesh.constructionmeasure"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.darwesh.constructionmeasure"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // ARCore - for AR-based distance/area measurement
    implementation("com.google.ar:core:1.44.0")

    // Sceneform-replacement: SceneView (maintained fork, since Google Sceneform is deprecated)
    implementation("io.github.sceneview:arsceneview:2.2.1")
}
