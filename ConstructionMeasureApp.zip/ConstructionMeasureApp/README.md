# Construction Measure App

Android app (Kotlin) for construction-site use: AR distance/area measurement,
material quantity calculator, and PDF export/share.

## Modules

1. **MeasurementActivity** — AR-based measurement using ARCore + SceneView.
   - Distance mode: tap two points on a detected surface.
   - Area mode: tap 3+ points to outline a shape; computes area (shoelace
     formula) and perimeter.
2. **CalculatorActivity** — material estimator. Takes an area in m² (auto-fills
   from your last AR area measurement) and estimates: floor tiles, wall
   paint, cement bags, or bricks needed, with a 10% wastage allowance.
3. **HistoryActivity** — lists everything saved this session and exports it
   as a PDF report (built with Android's native `PdfDocument`, no extra
   library needed) that you can share directly via WhatsApp/Email.

## New in this version

- **Urdu / English toggle** — a button on the home screen (`btn_language`)
  switches the whole app's language instantly via `LocaleHelper` +
  `BaseActivity`. All screens read text from `strings.xml` /
  `values-ur/strings.xml`, so adding more languages later just means adding
  another `values-xx/strings.xml` folder.
- **Cost calculation** — the calculator now has an optional "price per unit"
  field. If filled in, it multiplies by the estimated quantity to show a
  total estimated cost alongside the material quantity.
- **Finishing materials** — the material dropdown now also includes Marble
  Flooring, Granite Flooring, and Wood/Laminate Flooring (priced/measured by
  m²), in addition to the original tiles, paint, cement, and bricks.

## Setup

1. Open this folder in Android Studio (Koala or newer).
2. Let Gradle sync — it will pull ARCore and the SceneView library.
3. You need a **physical Android device with ARCore support** (most phones
   2018+). AR does not work in the emulator.
4. Run on device. Grant camera permission when prompted.

## Notes / things to double check before shipping

- **SceneView version**: `io.github.sceneview:arsceneview:2.2.1` is the
  dependency used here — it's a maintained, actively updated fork of
  Google's now-deprecated Sceneform. Check
  https://github.com/SceneView/sceneview-android for the latest version
  number and swap it in `app/build.gradle.kts` if a newer one exists.
- **Material formulas** in `CalculatorActivity.kt` (tile size, paint
  coverage, cement bags, bricks per m²) are rough industry rules of thumb.
  Adjust the constants to match your local suppliers' actual specs before
  relying on them for real orders.
- **Persistence**: `MeasurementStore` currently keeps records in memory only
  (cleared when the app closes). If you need history to survive app
  restarts, swap it for a Room database — the `MeasurementRecord` data
  class is already structured to drop into a Room `@Entity` with minimal
  changes.
- **Area accuracy**: AR area measurement assumes the tapped points are
  roughly on the same plane (a floor or a wall). For irregular/sloped
  surfaces, accuracy will drop.

## Suggested next features (from our chat)

- Belt/wallet-size customer-facing measurement mode for the online store
  side of the business (kept as a separate, simpler flow — construction and
  retail sizing have different accuracy needs).
- Cost calculator layered on top of the material calculator (quantity ×
  local price per unit).
